package com.String;

public class CharacterArray {

	public static void main(String[] args) {
		
		String s="siva";
		char[] ch=new char[]{'s','i','v','a'};
		
		System.out.println(ch);
		
		for(int i=0;i<ch.length;i++)
		System.out.println("password is:"+ch[i]);

	}

}
