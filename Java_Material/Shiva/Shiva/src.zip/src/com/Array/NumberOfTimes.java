package com.Array;

public class NumberOfTimes {

	public static void main(String[] args) {
		

	}

}
