package com.dataStructures;

public class SingleLinkedList {

	protected Node start;
	protected Node end;
	public int size;

	// Constructor

	public SingleLinkedList() {
		start = null;
		end = null;
		size = 0;
	}

}
