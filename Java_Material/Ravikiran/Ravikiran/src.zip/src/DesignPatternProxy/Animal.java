package DesignPatternProxy;

public interface Animal {
	public void getSound();
}

