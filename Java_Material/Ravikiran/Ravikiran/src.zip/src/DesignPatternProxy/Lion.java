package DesignPatternProxy;

public class Lion implements Animal {

	public void getSound() {
		System.out.println("Roar");
	}

}