package DsArrayList;
import java.util.*;

public class arrayImpl {

	public static void main (String arg[])
	 
	{
		ArrayList al = new ArrayList();
		al.add(11);
		al.add(12);
	    al.add(13);
	    al.add("rr");
    	al.add("Ra");
	    al.add("kk");
	    al.add(17);
	
	    
		for (int i = 0 ; i < al.length() ; i ++)
		{
			System.out.print(al.getIndex(i) + " ");
		}
		
		
		ArrayList ll = new ArrayList();	
		
	
		
	}
	
}
