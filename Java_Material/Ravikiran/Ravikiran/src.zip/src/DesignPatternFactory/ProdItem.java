package DesignPatternFactory;

public interface ProdItem {

	public void itemlist();

}
