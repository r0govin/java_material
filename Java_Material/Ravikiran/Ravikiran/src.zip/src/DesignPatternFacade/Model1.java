package DesignPatternFacade;

public class Model1 implements Design{

	public void designFun()
	{
		System.out.println("Model Design");
	}

}
