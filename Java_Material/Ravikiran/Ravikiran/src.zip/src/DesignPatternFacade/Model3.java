package DesignPatternFacade;

public class Model3 implements Design{

	public void designFun() 
	{		
		System.out.println("Model3 Design");
	}
	

}
