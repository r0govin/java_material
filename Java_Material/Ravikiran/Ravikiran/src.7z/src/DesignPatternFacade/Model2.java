package DesignPatternFacade;

public class Model2 implements Design
{

	public void designFun() 
	{
		System.out.println("Model2 Design");		
	}

}
