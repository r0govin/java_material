package DesignPatternFacade;

public interface Design 
{
	public void designFun ();			
}
