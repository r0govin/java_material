package DesignPatternFactory;

public class product3 implements ProdItem
{
	 public void itemlist() 
	    {		
			System.out.println("Product 3 item list");
		}

}
