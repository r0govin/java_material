package DsLinkedList;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class kkk {

	public static <E> void main (String arg[]){
//		List<Character> ll = new ArrayList<Character>();
//		ll.add(1);
//		ll.add("kiran");
//	//	System.out.println(ll);
//		
//		Iterator<E> itr = ll.iterator();
//		while (itr.hasNext()){
//			System.out.println(itr.next());
//			E p = itr.next();
		}
	}
	
	
	
	

