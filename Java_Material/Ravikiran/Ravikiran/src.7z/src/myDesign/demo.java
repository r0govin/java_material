package myDesign;

public class demo {
	public static void main (String arg[]){
		String str = "india";
		CarFactory.createCurrency(str).setSymbol();	
	}
}
